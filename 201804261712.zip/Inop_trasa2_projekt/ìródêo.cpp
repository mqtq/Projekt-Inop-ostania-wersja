/*
Opis: plik main
Autor: Mateusz Wasiak, Marcin Ludwisiak, Jakub Zi�ba, Martyna R�j, Damian Goss
Data utworzenia: 19.04.2018r.
Modyfikacje pliku:

------------------------------------------------------------
ToDo:

*/


#include <iostream>
#include "_Teren_.h"

int main()
{


	system("pause");
	return 0;
}